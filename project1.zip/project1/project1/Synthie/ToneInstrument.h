#pragma once

#include "Instrument.h"
#include "SineWave.h"
#include "AR.h"
#include "Note.h"
#include <atlcomcli.h> // For CComPtr

class CToneInstrument : public CInstrument
{
public:
     // Constructors and destructor
     CToneInstrument();
     CToneInstrument(double bpm);
     virtual ~CToneInstrument();

     // Core methods
     virtual void Start() override;
     virtual bool Generate(double* frame) override;
     virtual void SetNote(CNote* note) override;

     // Method to set frequency directly
     void SetFreq(double freq);

private:
     CSineWave m_sinewave;  // Sine wave generator
     CAR m_ar;              // Attack-release envelope
     double m_duration;     // Duration of the note
     double m_bpm;          // Beats per minute
     double m_time;         // Current time during playback
};
