#pragma once
#include "AudioNode.h"
#include <cmath>

class CSineWave : public CAudioNode
{
public:
     CSineWave();
     virtual ~CSineWave();

     //! Start audio generation
     virtual void Start() override;

     //! Generate one frame of audio
     virtual bool Generate(double* frame) override;

     //! Set the sine wave frequency
     void SetFreq(double f) { m_freq = f; }

     //! Set the sine wave amplitude
     void SetAmplitude(double a) { m_amp = a; }

private:
     double m_freq;    // Frequency of the sine wave (in Hz)
     double m_amp;     // Amplitude of the sine wave
     double m_phase;   // Current phase of the sine wave (in radians)
};
