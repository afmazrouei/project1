#include "stdafx.h" 
#include "EffectsComponent.h"
#include <cmath> 

#ifndef M_PI
#define M_PI 3.14159265358979323846 
#endif

CEffectsComponent::CEffectsComponent()
     : m_dryMix(1.0), m_wetMix(0.0), m_reverbAmount(0.0),
     m_chorusDepth(0.0), m_chorusRate(0.0),
     m_compressionThreshold(0.5), m_compressionRatio(2.0),
     m_flangeDepth(0.0), m_flangeRate(0.0),
     m_time(0.0)
{
}

CEffectsComponent::~CEffectsComponent() {}

void CEffectsComponent::Start()
{
     m_time = 0.0; 
}

bool CEffectsComponent::Generate(double* frame)
{
     double inputSample = frame[0]; 

     // Apply dry/wet mix
     double drySample = inputSample * m_dryMix;
     double wetSample = inputSample;

     // Apply individual effects
     if (m_reverbAmount > 0.0)
     {
          wetSample = ApplyReverb(wetSample);
     }

     if (m_chorusDepth > 0.0 && m_chorusRate > 0.0)
     {
          wetSample = ApplyChorus(wetSample, m_time);
     }

     if (m_flangeDepth > 0.0 && m_flangeRate > 0.0)
     {
          wetSample = ApplyFlanging(wetSample, m_time);
     }

     if (m_compressionThreshold > 0.0)
     {
          wetSample = ApplyCompression(wetSample);
     }

     // Combine dry and wet signals
     frame[0] = (drySample * (1.0 - m_wetMix)) + (wetSample * m_wetMix);
     frame[1] = frame[0]; // Assuming stereo output

     // Increment time for effects that need it
     m_time += 1.0 / m_sampleRate;

     return true;
}

void CEffectsComponent::SetNote(CNote* note)
{
     if (note)
     {
          
     }
}

void CEffectsComponent::SetReverbAmount(double reverbAmount)
{
     m_reverbAmount = reverbAmount;
}

void CEffectsComponent::SetChorusDepth(double depth)
{
     m_chorusDepth = depth;
}

void CEffectsComponent::SetChorusRate(double rate)
{
     m_chorusRate = rate;
}

void CEffectsComponent::SetCompression(double threshold, double ratio)
{
     m_compressionThreshold = threshold;
     m_compressionRatio = ratio;
}

void CEffectsComponent::SetFlangeDepth(double depth)
{
     m_flangeDepth = depth;
}

void CEffectsComponent::SetFlangeRate(double rate)
{
     m_flangeRate = rate;
}

void CEffectsComponent::SetDryWetMix(double dry, double wet)
{
     m_dryMix = dry;
     m_wetMix = wet;
}

double CEffectsComponent::ApplyReverb(double sample)
{
     // Simplified reverb implementation
     double reverbSample = sample * m_reverbAmount * 0.5; 
     return sample + reverbSample;
}

double CEffectsComponent::ApplyChorus(double sample, double time)
{
     // Simple chorus implementation using a sine wave modulation
     double modulatedSample = sample + m_chorusDepth * sin(2 * M_PI * m_chorusRate * time);
     return modulatedSample;
}

double CEffectsComponent::ApplyFlanging(double sample, double time)
{
     // Simple flanging effect using a sine wave for delay modulation
     double delayedSample = sample + m_flangeDepth * sin(2 * M_PI * m_flangeRate * time);
     return delayedSample;
}

double CEffectsComponent::ApplyCompression(double sample)
{
     // Simple compression implementation
     if (std::abs(sample) > m_compressionThreshold)
     {
          sample = (sample > 0) ? m_compressionThreshold + (sample - m_compressionThreshold) / m_compressionRatio
               : -m_compressionThreshold + (sample + m_compressionThreshold) / m_compressionRatio;
     }
     return sample;
}
