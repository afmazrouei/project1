#include "stdafx.h"
#include "AR.h"

CAR::CAR()
     : m_duration(0), m_time(0), m_attack(0), m_release(0), m_source(nullptr)
{
}

CAR::~CAR()  // Ensure this is only defined here
{
}

void CAR::Start()
{
     m_time = 0;
     if (m_source)
     {
          m_source->Start();
     }
}

bool CAR::Generate(double* frame)
{
     if (!m_source)
     {
          frame[0] = frame[1] = 0.0;
          return false;
     }

     if (m_time < m_attack)
     {
          double gain = m_time / m_attack;
          m_source->Generate(frame);
          frame[0] *= gain;
          frame[1] *= gain;
     }
     else if (m_time > m_duration - m_release)
     {
          double gain = (m_duration - m_time) / m_release;
          if (gain < 0) gain = 0;
          m_source->Generate(frame);
          frame[0] *= gain;
          frame[1] *= gain;
     }
     else
     {
          m_source->Generate(frame);
     }

     m_time += GetSamplePeriod();

     return m_time < m_duration;
}
