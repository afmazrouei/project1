#include "stdafx.h"
#include "WavetableSynthesizer.h"
#include <cmath>
#include <algorithm>

CWavetableSynthesizer::CWavetableSynthesizer()
     : m_sampleRate(44100), m_pitch(1.0), m_time(0.0), m_loopStart(0), m_loopEnd(0),
     m_crossfadeEnabled(false), m_attack(0.01), m_decay(0.1), m_sustain(0.7), m_release(0.2)
{
}

CWavetableSynthesizer::~CWavetableSynthesizer() {}

void CWavetableSynthesizer::Start()
{
     m_time = 0.0; // Reset time
}

bool CWavetableSynthesizer::Generate(double* frame)
{
     if (m_waveform.empty())
     {
          frame[0] = frame[1] = 0.0;
          return false;
     }

     // Calculate the current index in the waveform
     int index = static_cast<int>(m_time * m_sampleRate * m_pitch) % m_waveform.size();

     // Apply loop points logic
     if (m_time * m_sampleRate >= m_loopEnd && m_loopEnd > 0)
     {
          m_time = m_loopStart / static_cast<double>(m_sampleRate);
     }

     // Get the current sample
     double sample = GetCurrentSample();

     // Apply the envelope
     sample = ApplyEnvelope(sample);

     // Apply crossfade if enabled
     if (m_crossfadeEnabled)
     {
          sample = ApplyCrossfade(sample);
     }

     // Output the sample to both stereo channels
     frame[0] = frame[1] = sample;

     // Increment time
     m_time += 1.0 / m_sampleRate;

     return true;
}

void CWavetableSynthesizer::SetNote(CNote* note)
{
     if (note)
     {
          // Set the pitch or any other properties from the note as needed
          m_pitch = note->GetPitch();
     }
}

void CWavetableSynthesizer::SetWaveform(const std::vector<double>& waveform)
{
     m_waveform = waveform;
}

void CWavetableSynthesizer::SetEnvelope(double attack, double decay, double sustain, double release)
{
     m_attack = attack;
     m_decay = decay;
     m_sustain = sustain;
     m_release = release;
}

void CWavetableSynthesizer::SetLoopPoints(int start, int end)
{
     m_loopStart = start;
     m_loopEnd = end;
}

double CWavetableSynthesizer::ApplyEnvelope(double sample)
{
     double envelopeValue = 1.0;

     // Apply ADSR envelope logic (simplified example)
     if (m_time < m_attack)
     {
          envelopeValue = m_time / m_attack; // Attack phase
     }
     else if (m_time < m_attack + m_decay)
     {
          envelopeValue = 1.0 - ((m_time - m_attack) / m_decay) * (1.0 - m_sustain); // Decay phase
     }
     else
     {
          envelopeValue = m_sustain; // Sustain phase
     }

     return sample * envelopeValue;
}

double CWavetableSynthesizer::ApplyCrossfade(double sample)
{
     // Simple crossfade implementation between two samples (demonstrative)
     // Adjust as needed for richer sound variation
     int nextIndex = (static_cast<int>(m_time * m_sampleRate * m_pitch) + 1) % m_waveform.size();
     double nextSample = m_waveform[nextIndex];
     double crossfadeAmount = 0.5; // Replace with a variable for dynamic crossfade control
     return (sample * (1.0 - crossfadeAmount)) + (nextSample * crossfadeAmount);
}

double CWavetableSynthesizer::GetCurrentSample()
{
     int index = static_cast<int>(m_time * m_sampleRate * m_pitch) % m_waveform.size();
     return m_waveform[index];
}
