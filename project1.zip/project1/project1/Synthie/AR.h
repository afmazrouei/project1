#pragma once
#include "AudioNode.h"

// Class for an Attack-Release envelope generator
class CAR : public CAudioNode
{
public:
     CAR();
     virtual ~CAR();

     // Set the source audio node
     void SetSource(CAudioNode* source) { m_source = source; }

     // Set the duration of the envelope
     void SetDuration(double d) { m_duration = d; }

     // Set the attack time
     void SetAttack(double a) { m_attack = a; }

     // Set the release time
     void SetRelease(double r) { m_release = r; }

     // Start the audio node
     virtual void Start() override;

     // Generate a frame of audio
     virtual bool Generate(double* frame) override;

private:
     double m_duration;   // Total duration of the envelope
     double m_time;       // Current time in the envelope cycle
     double m_attack;     // Attack time in seconds
     double m_release;    // Release time in seconds
     CAudioNode* m_source; // Pointer to the source audio node
};
