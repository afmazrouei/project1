#pragma once
#include "Instrument.h"
#include "Note.h"

// Class for handling audio effects as an instrument
class CEffectsComponent : public CInstrument
{
public:
     CEffectsComponent();
     virtual ~CEffectsComponent();

     // Core methods overridden from CInstrument
     virtual void Start() override;
     virtual bool Generate(double* frame) override;
     virtual void SetNote(CNote* note) override;

     // Methods to set effects properties
     void SetReverbAmount(double reverbAmount);
     void SetChorusDepth(double depth);
     void SetChorusRate(double rate);
     void SetCompression(double threshold, double ratio);
     void SetFlangeDepth(double depth);
     void SetFlangeRate(double rate);
     void SetDryWetMix(double dry, double wet);

private:
     double m_reverbAmount;  
     double m_chorusDepth;   
     double m_chorusRate;    
     double m_compressionThreshold; 
     double m_compressionRatio;     
     double m_flangeDepth;   
     double m_flangeRate;    
     double m_dryMix;        
     double m_wetMix;        
     double m_time;          

     // Helper methods for applying individual effects
     double ApplyReverb(double sample);
     double ApplyChorus(double sample, double time);
     double ApplyFlanging(double sample, double time);
     double ApplyCompression(double sample);
};
