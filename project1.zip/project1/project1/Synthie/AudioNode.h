#pragma once

// Base class for all audio processing nodes
class CAudioNode
{
public:
     CAudioNode() noexcept;
     CAudioNode(double bpm) noexcept;
     virtual ~CAudioNode() noexcept;

     // Pure virtual methods to be implemented by derived classes
     virtual void Start() = 0;
     virtual bool Generate(double* frame) = 0;

     // Getters and setters for sample rate
     double GetSampleRate() const noexcept { return m_sampleRate; }
     void SetSampleRate(double s) noexcept { m_sampleRate = s; m_samplePeriod = 1.0 / s; }

     // Get sample period
     double GetSamplePeriod() const noexcept { return m_samplePeriod; }

     // Access generated audio frame
     const double* Frame() const noexcept { return m_frame; }
     double Frame(int c) const noexcept { return m_frame[c]; }

protected:
     double m_sampleRate;   // Sample rate in samples per second
     double m_samplePeriod; // Sample period in seconds (1/sampleRate)
     double m_bpm;          // Beats per minute
     double m_frame[2];     // Audio frame for stereo output (left and right channels)
};
