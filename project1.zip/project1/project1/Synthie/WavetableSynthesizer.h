#pragma once
#include "Instrument.h"
#include "Note.h"
#include <vector>

class CWavetableSynthesizer : public CInstrument
{
public:
     CWavetableSynthesizer();
     virtual ~CWavetableSynthesizer();

     // Core methods
     void Start() override;
     bool Generate(double* frame) override;
     void SetNote(CNote* note) override;

     // Methods to set properties
     void SetSampleRate(double sampleRate) { m_sampleRate = sampleRate; }
     void SetWaveform(const std::vector<double>& waveform);
     void SetPitch(double pitch) { m_pitch = pitch; }
     void SetEnvelope(double attack, double decay, double sustain, double release);
     void SetLoopPoints(int start, int end);
     void EnableCrossfade(bool enable) { m_crossfadeEnabled = enable; }

private:
     std::vector<double> m_waveform; 
     double m_sampleRate;            
     double m_pitch;               
     double m_time;                  
     int m_loopStart;                
     int m_loopEnd;                  
     bool m_crossfadeEnabled;       
     double m_attack, m_decay, m_sustain, m_release; 

     // Helper functions
     double ApplyEnvelope(double sample);
     double ApplyCrossfade(double sample);
     double GetCurrentSample();
};
