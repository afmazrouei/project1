#include "stdafx.h"
#include "Synthesizer.h"
#include "WavetableSynthesizer.h"
#include "EffectsComponent.h"
#include "Instrument.h"
#include "ToneInstrument.h"
#include "xmlhelp.h"
#include <vector>
#include <algorithm>
#include <comutil.h>
#include <numbers>

CSynthesizer::CSynthesizer()
     : m_time(0)
{
     CoInitialize(NULL);
     m_channels = 2;
     m_sampleRate = 44100.0;
     m_samplePeriod = 1.0 / m_sampleRate;
     m_bpm = 120;
     m_beatspermeasure = 4;
     m_secperbeat = 0.5;
}

CSynthesizer::~CSynthesizer()
{
}

//! Start the synthesizer
void CSynthesizer::Start()
{
     m_instruments.clear();
     m_currentNote = 0;
     m_measure = 0;
     m_beat = 0;
     m_time = 0.0;

     // Initialize wavetable synthesizer
     m_wavetableSynth.SetSampleRate(GetSampleRate());
     m_wavetableSynth.Start();

     // Initialize effects component
     m_effectsComponent.SetSampleRate(GetSampleRate());
     m_effectsComponent.Start();
}

bool CSynthesizer::Generate(double* frame)
{
     // Phase 1: Check if any new notes need to be played
     while (m_currentNote < static_cast<int>(m_notes.size()))
     {
          CNote* note = &m_notes[m_currentNote];

          // Check if the note should be played at this measure and beat
          if (note->Measure() > m_measure ||
               (note->Measure() == m_measure && note->Beat() > m_beat))
          {
               break;
          }

          // Create the appropriate instrument for the note
          CInstrument* instrument = nullptr;
          if (note->Instrument() == L"Wavetable")
          {
               instrument = new CWavetableSynthesizer();
          }
          else if (note->Instrument() == L"Effect")
          {
               instrument = new CEffectsComponent();
          }

          // Configure and start the instrument if it was created
          if (instrument != nullptr)
          {
               instrument->SetSampleRate(GetSampleRate());
               instrument->SetNote(note);
               instrument->Start();
               m_instruments.push_back(instrument);
          }

          // Move to the next note
          m_currentNote++;
     }

     // Phase 2: Clear all channels to silence
     for (int c = 0; c < GetNumChannels(); ++c)
     {
          frame[c] = 0.0;
     }

     // Phase 3: Generate audio for all active instruments
     for (auto it = m_instruments.begin(); it != m_instruments.end();)
     {
          CInstrument* instrument = *it;
          if (instrument->Generate(frame))
          {
               for (int c = 0; c < GetNumChannels(); ++c)
               {
                    frame[c] += instrument->Frame(c);
               }
               ++it;
          }
          else
          {
               // Instrument is done playing, so remove it
               delete instrument;
               it = m_instruments.erase(it);
          }
     }

     // Phase 4: Integrate the wavetable synthesizer output
     double wavetableFrame[2] = { 0.0, 0.0 };
     if (m_wavetableSynth.Generate(wavetableFrame))
     {
          for (int c = 0; c < GetNumChannels(); ++c)
          {
               frame[c] += wavetableFrame[c];
          }
     }

     // Phase 5: Apply audio effects to the frame
     m_effectsComponent.Generate(frame);

     // Phase 6: Advance time and beats
     m_time += GetSamplePeriod();
     m_beat += GetSamplePeriod() / m_secperbeat;

     // Advance to the next measure if needed
     if (m_beat >= m_beatspermeasure)
     {
          m_beat -= m_beatspermeasure;
          m_measure++;
     }

     // Phase 7: Determine if the synthesizer should continue generating audio
     return !m_instruments.empty() || m_currentNote < static_cast<int>(m_notes.size());
}

// Get the time since we started generating audio
double CSynthesizer::GetTime() const
{
     return m_time;
}

void CSynthesizer::Clear()
{
     m_instruments.clear();
     m_notes.clear();
}

void CSynthesizer::XmlLoadScore(IXMLDOMNode* xml)
{
     // Get a list of all attribute nodes and the length of that list
     CComPtr<IXMLDOMNamedNodeMap> attributes;
     xml->get_attributes(&attributes);
     long len;
     attributes->get_length(&len);

     // Loop over the list of attributes
     for (int i = 0; i < len; i++)
     {
          // Get attribute i
          CComPtr<IXMLDOMNode> attrib;
          attributes->get_item(i, &attrib);

          // Get the name of the attribute
          CComBSTR name;
          attrib->get_nodeName(&name);

          // Get the value of the attribute
          CComVariant value;
          attrib->get_nodeValue(&value);

          if (name == L"bpm")
          {
               value.ChangeType(VT_R8);
               m_bpm = value.dblVal;
               m_secperbeat = 1.0 / (m_bpm / 60.0);
          }
          else if (name == L"beatspermeasure")
          {
               value.ChangeType(VT_I4);
               m_beatspermeasure = value.intVal;
          }
     }

     CComPtr<IXMLDOMNode> node;
     xml->get_firstChild(&node);
     for (; node != NULL; NextNode(node))
     {
          // Get the name of the node
          CComBSTR name;
          node->get_nodeName(&name);
          if (name == L"instrument")
          {
               XmlLoadInstrument(node);
          }
     }
}

void CSynthesizer::OpenScore(CString& filename)
{
     Clear();

     // Create an XML document
     CComPtr<IXMLDOMDocument> pXMLDoc;
     bool succeeded = SUCCEEDED(CoCreateInstance(CLSID_DOMDocument, NULL, CLSCTX_INPROC_SERVER,
          IID_IXMLDOMDocument, (void**)&pXMLDoc));
     if (!succeeded)
     {
          AfxMessageBox(L"Failed to create an XML document to use");
          return;
     }

     // Open the XML document
     VARIANT_BOOL ok;
     succeeded = SUCCEEDED(pXMLDoc->load(CComVariant(filename), &ok));
     if (!succeeded || ok == VARIANT_FALSE)
     {
          AfxMessageBox(L"Failed to open XML score file");
          return;
     }

     // Traverse the XML document in memory
     CComPtr<IXMLDOMNode> node;
     pXMLDoc->get_firstChild(&node);
     for (; node != NULL; NextNode(node))
     {
          // Get the name of the node
          CComBSTR nodeName;
          node->get_nodeName(&nodeName);
          if (nodeName == L"score")
          {
               XmlLoadScore(node);
          }
     }
     sort(m_notes.begin(), m_notes.end());
}

void CSynthesizer::XmlLoadInstrument(IXMLDOMNode* xml)
{
     std::wstring instrument = L"";
     CComPtr<IXMLDOMNamedNodeMap> attributes;
     xml->get_attributes(&attributes);
     long len;
     attributes->get_length(&len);

     for (int i = 0; i < len; i++)
     {
          CComPtr<IXMLDOMNode> attrib;
          attributes->get_item(i, &attrib);
          CComBSTR name;
          attrib->get_nodeName(&name);
          CComVariant value;
          attrib->get_nodeValue(&value);

          // Convert CComBSTR and CComVariant to std::wstring for comparison
          std::wstring nameStr = (name != nullptr) ? static_cast<const wchar_t*>(name) : L"";
          _bstr_t valueStr(value); // Safely convert CComVariant to BSTR

          if (nameStr == L"instrument")
          {
               instrument = static_cast<const wchar_t*>(valueStr);
          }
     }

     if (instrument == L"Wavetable")
     {
          // Parse parameters specific to the WavetableSynthesizer
          // Set waveform, pitch, etc., based on XML attributes
     }

     if (instrument == L"Effect")
     {
          // Parse parameters specific to the EffectsComponent
          // Set reverb, chorus, compression, etc., based on XML attributes
     }

     CComPtr<IXMLDOMNode> node;
     xml->get_firstChild(&node);
     for (; node != NULL; NextNode(node))
     {
          CComBSTR name;
          node->get_nodeName(&name);
          std::wstring nodeName = (name != nullptr) ? static_cast<const wchar_t*>(name) : L"";

          if (nodeName == L"note")
          {
               XmlLoadNote(node, instrument);
          }
     }
}

void CSynthesizer::XmlLoadNote(IXMLDOMNode* xml, std::wstring& instrument)
{
     m_notes.push_back(CNote());
     m_notes.back().XmlLoad(xml, instrument);
}
