#pragma once
#include "AudioNode.h"
#include "Note.h"

// Base class for instruments that generate audio based on musical notes
class CInstrument : public CAudioNode
{
public:
     CInstrument() noexcept;
     CInstrument(double bpm) noexcept;
     virtual ~CInstrument() noexcept;

     // Pure virtual method to be implemented by derived classes
     virtual void SetNote(CNote* note) = 0;

protected:
     CNote* m_note; // Pointer to the current note, managed externally
};
