#include "stdafx.h"
#include "ToneInstrument.h"
#include "Notes.h"

CToneInstrument::CToneInstrument()
     : m_duration(0.1), m_bpm(120.0), m_time(0.0) // Default BPM and time initialization
{
}

// Constructor to set the beats per minute
CToneInstrument::CToneInstrument(double bpm)
     : m_duration(0.1), m_bpm(bpm), m_time(0.0)
{
}

CToneInstrument::~CToneInstrument()
{
}

void CToneInstrument::Start()
{
     // Initialize sine wave generator
     m_sinewave.SetSampleRate(GetSampleRate());
     m_sinewave.Start();

     // Set up the attack-release (AR) envelope
     m_ar.SetSource(&m_sinewave);
     m_ar.SetSampleRate(GetSampleRate());
     m_ar.Start();

     // Reset the current time
     m_time = 0.0;
}

bool CToneInstrument::Generate(double* frame)
{
     // Generate audio frame using the AR envelope
     bool valid = m_ar.Generate(frame);

     // Copy generated frame data to the instrument's frame
     m_frame[0] = frame[0];
     m_frame[1] = frame[1];

     // Update time
     m_time += GetSamplePeriod();

     // Return true as long as the AR envelope is valid
     return valid && m_time < m_duration;
}

void CToneInstrument::SetNote(CNote* note)
{
     // Get a list of all attribute nodes and the length of that list
     CComPtr<IXMLDOMNamedNodeMap> attributes;
     note->Node()->get_attributes(&attributes);
     long len;
     attributes->get_length(&len);

     // Loop over the list of attributes
     for (int i = 0; i < len; i++)
     {
          // Get attribute i
          CComPtr<IXMLDOMNode> attrib;
          attributes->get_item(i, &attrib);

          // Get the name of the attribute
          CComBSTR name;
          attrib->get_nodeName(&name);

          // Get the value of the attribute
          CComVariant value;
          attrib->get_nodeValue(&value);

          if (name == L"duration")
          {
               value.ChangeType(VT_R8);
               m_ar.SetDuration(value.dblVal * (60.0 / m_bpm)); // Adjust duration based on BPM
               m_duration = value.dblVal; // Store duration for reference
          }
          else if (name == L"note")
          {
               value.ChangeType(VT_BSTR);
               SetFreq(NoteToFrequency(value.bstrVal)); // Set frequency based on the note value
          }
     }
}

void CToneInstrument::SetFreq(double freq)
{
     m_sinewave.SetFreq(freq);
}
