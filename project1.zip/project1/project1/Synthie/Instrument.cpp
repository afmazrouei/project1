#include "stdafx.h"
#include "Instrument.h"

CInstrument::CInstrument() noexcept : m_note(nullptr)
{
}

// Constructor to set the beats per minute
CInstrument::CInstrument(double bpm) noexcept : CAudioNode(bpm), m_note(nullptr)
{
}

CInstrument::~CInstrument() noexcept
{
     // No special cleanup is needed if m_note is managed externally.
     // If m_note is owned by this class, you might need to delete it here.
}

// Implementation of any additional common methods for instruments can be added here
