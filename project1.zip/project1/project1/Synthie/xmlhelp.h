#pragma once

#include <msxml2.h>
#include <string>

/*! This function accepts a reference to a node pointer
 *  and advances it to the next sibling node.
 */
inline void NextNode(CComPtr<IXMLDOMNode>& node)
{
     CComPtr<IXMLDOMNode> next;
     node->get_nextSibling(&next);
     node = next;
}

/*! This function retrieves the value of a given attribute from an XML node.
 *  @param node The XML node containing the attribute.
 *  @param attributeName The name of the attribute to retrieve.
 *  @param value A reference to a CComVariant to store the value.
 *  @return True if the attribute was found and its value was successfully retrieved, false otherwise.
 */
inline bool GetAttributeValue(CComPtr<IXMLDOMNode> node, const std::wstring& attributeName, CComVariant& value)
{
     CComPtr<IXMLDOMNamedNodeMap> attributes;
     node->get_attributes(&attributes);
     if (attributes)
     {
          CComPtr<IXMLDOMNode> attributeNode;
          if (SUCCEEDED(attributes->getNamedItem(CComBSTR(attributeName.c_str()), &attributeNode)) && attributeNode)
          {
               attributeNode->get_nodeValue(&value);
               return true;
          }
     }
     return false;
}

/*! This function converts a CComVariant to a string.
 *  @param variant The CComVariant to convert.
 *  @return A std::wstring representing the value of the CComVariant.
 */
inline std::wstring VariantToString(const CComVariant& variant)
{
     CComVariant tempVariant = variant;
     tempVariant.ChangeType(VT_BSTR);
     return tempVariant.bstrVal ? std::wstring(tempVariant.bstrVal) : L"";
}

/*! This function converts a CComVariant to an integer.
 *  @param variant The CComVariant to convert.
 *  @return An integer representing the value of the CComVariant.
 */
inline int VariantToInt(const CComVariant& variant)
{
     CComVariant tempVariant = variant;
     tempVariant.ChangeType(VT_I4);
     return tempVariant.intVal;
}

/*! This function converts a CComVariant to a double.
 *  @param variant The CComVariant to convert.
 *  @return A double representing the value of the CComVariant.
 */
inline double VariantToDouble(const CComVariant& variant)
{
     CComVariant tempVariant = variant;
     tempVariant.ChangeType(VT_R8);
     return tempVariant.dblVal;
}

/*! This function retrieves the name of an XML node.
 *  @param node The XML node.
 *  @return A std::wstring representing the name of the node.
 */
inline std::wstring GetNodeName(CComPtr<IXMLDOMNode> node)
{
     CComBSTR nodeName;
     node->get_nodeName(&nodeName);
     return nodeName ? std::wstring(nodeName) : L"";
}

/*! This function retrieves the text content of an XML node.
 *  @param node The XML node.
 *  @return A std::wstring representing the text content of the node.
 */
inline std::wstring GetNodeText(CComPtr<IXMLDOMNode> node)
{
     CComBSTR textContent;
     node->get_text(&textContent);
     return textContent ? std::wstring(textContent) : L"";
}

/*! This function retrieves the first child node with a specific name.
 *  @param parentNode The parent XML node.
 *  @param childName The name of the child node to find.
 *  @return A CComPtr to the first child node with the specified name, or nullptr if not found.
 */
inline CComPtr<IXMLDOMNode> GetFirstChildNodeByName(CComPtr<IXMLDOMNode> parentNode, const std::wstring& childName)
{
     CComPtr<IXMLDOMNode> childNode;
     parentNode->get_firstChild(&childNode);
     while (childNode)
     {
          if (GetNodeName(childNode) == childName)
          {
               return childNode;
          }
          NextNode(childNode);
     }
     return nullptr;
}
