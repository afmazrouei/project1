#include "stdafx.h"
#include "SineWave.h"
#include <cmath> // Ensure cmath is included for the sin() function

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

CSineWave::CSineWave()
     : m_phase(0), m_amp(0.1), m_freq(440)
{
}

CSineWave::~CSineWave()
{
}

void CSineWave::Start()
{
     m_phase = 0;
}

bool CSineWave::Generate(double* frame)
{
     // Generate the sine wave for one frame and fill both channels
     double sample = m_amp * sin(m_phase * 2 * M_PI);
     frame[0] = sample; // Left channel
     frame[1] = sample; // Right channel

     // Update the phase for the next sample
     m_phase += m_freq * GetSamplePeriod();

     // Keep the phase in the range [0, 2*PI] to prevent overflow
     if (m_phase >= 2 * M_PI)
     {
          m_phase -= 2 * M_PI;
     }

     return true;
}
