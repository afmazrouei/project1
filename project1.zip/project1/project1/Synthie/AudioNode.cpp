#include "stdafx.h"
#include "AudioNode.h"

CAudioNode::CAudioNode() noexcept
     : m_sampleRate(44100), m_samplePeriod(1.0 / 44100.0), m_bpm(120)
{
     m_frame[0] = 0.0;
     m_frame[1] = 0.0;
}

// Constructor that takes a BPM parameter
CAudioNode::CAudioNode(double bpm) noexcept
     : m_sampleRate(44100), m_samplePeriod(1.0 / 44100.0), m_bpm(bpm)
{
     m_frame[0] = 0.0;
     m_frame[1] = 0.0;
}

// Destructor definition
CAudioNode::~CAudioNode() noexcept
{
}
