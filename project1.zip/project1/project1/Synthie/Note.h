#pragma once
#include <string>
#include <comdef.h> // For CComPtr and IXMLDOMNode

class CNote
{
public:
     CNote();
     virtual ~CNote();

     // Accessors
     int Measure() const { return m_measure; }
     double Beat() const { return m_beat; }
     const std::wstring& Instrument() const { return m_instrument; }
     IXMLDOMNode* Node() { return m_node; }

     // Method to load XML data
     void XmlLoad(IXMLDOMNode* xml, std::wstring& instrument);

     // Operator for sorting notes
     bool operator<(const CNote& b);

     // Method to get pitch
     double GetPitch() const { return m_pitch; }

     // Method to set pitch (useful if needed)
     void SetPitch(double pitch) { m_pitch = pitch; }

private:
     std::wstring m_instrument;
     int m_measure;
     double m_beat;
     double m_pitch; // Member variable to store pitch
     CComPtr<IXMLDOMNode> m_node;
};
